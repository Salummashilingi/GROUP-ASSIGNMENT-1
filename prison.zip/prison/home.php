<html>
<title>home</title>

<body bgcolor="grey">
<div ALIGN="center"><font size="+1">
&nbsp;&nbsp;<a href="home.php"><href title="Home">HOME</a>
&nbsp;&nbsp;<a href="Performance Measure.php"><href title="Performance Measure">Performance Measure &nbsp;&nbsp;</a>
&nbsp;&nbsp;<a href="Recruitment.php"><href title="Recruitment">Recruitment &nbsp;&nbsp;</a>
&nbsp;&nbsp;<a href="employee details.php"><href title="employee details">employee details &nbsp;&nbsp;</a>
&nbsp;&nbsp;<a href="leaveform.php"><href title="leaveform">leaveform &nbsp;&nbsp;</a>
&nbsp;&nbsp;<a href="Announcements.php"><href title="Announcements">Announcements &nbsp;&nbsp;</a>
&nbsp;&nbsp;<a href="Training.php"><href title="Training">Training &nbsp;&nbsp;</a>
&nbsp;&nbsp;<a href="Salary.php"><href title="Salary">Salary &nbsp;&nbsp;</a>
</body>
</html>