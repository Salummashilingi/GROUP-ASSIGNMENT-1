<tr>
     <td colspan="5" bgcolor="#yellow" height="1" align="center">
		      <h1 class="bg-primary"><font size="5">
	           <a href="index.php">Home</a> |  	 
		        <a href="login2.php">LoginAccess </a> |
		        <a href="section.php">Prison Location</a> |
		        <a href="location.php">About Us</a>|
		        <a href="announce.php">Commments</a>
		        </font></h1>
            </td>
        </tr>