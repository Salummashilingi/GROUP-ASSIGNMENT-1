<?php
	include("config.php");
?>
<!DOCTYPE php>
<html>
<head>
	<title>Home</title>
	<meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="login.css"/>
</head>
<body>
	<header>
		<img src="banner.GIF" alt="JKUAT" class="jkuat">
		<div id="header">
			<div id="menu">
				<ul>
					<li><a href="add.php">Add New prison</a></li>
					<li><a href="vieuwAnnounce1.php">Comment</a></li>
					<li><a href="viewprisoners1.php">Prisoners Information</a></li> 
					<li><a href="viewcourt1.php">Court Information</a></li>
					<li><a href="viewtransfer1.php">Prisoners Transfer Information</a></li>
 					<li><a href="../index..php">Log Out</a></li>

				</ul>
				</ul>
			</div>
			
		</div>
	</header>


			