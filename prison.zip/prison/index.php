<html>
<head>
   
  <link rel="stylesheet" media="screen" href="login.css" >
</head>
<body>
  <table align="center" border="0" bgcolor="green" width="540" cellpadding="9" cellspacing="0" height="525">
          <tr>
            <td colspan="3" height="2"><img src="banner.gif" width="860"></td>
          </tr>
          <tr>
            <td colspan="3" bgcolor="#FF0000" height="1" align="center">
        <font size="4">
            <a href="index.php">HOME</a>  |
            <a href="location.php">ABOUT US</a>|
            <a href="login2.php">LOGIN </a> |
            
            <a href="location.php">ABOUT US</a>|
            <a href="announce.php">COMMENT</a> 
          </font>
            </td>
          </tr>
          <tr>
            <td width="50%" align="center" bgcolor="#FFFFFF">
       
<div class="ex">
       <h2 class="bg-primary">Prison Mngnt System Online </h2>

<tr>
  <?php
           include("footer.php");
                ?>
</tr>

</table>
</body>
</html>