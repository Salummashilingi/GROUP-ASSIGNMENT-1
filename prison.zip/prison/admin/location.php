<html>
<head>
  <title>KENYA PRISONS SERVICE</title>
   <link rel="stylesheet" media="screen" href="login.css" >
</head>
<body>
	<table align='center' border='0' bgcolor='green' width='820' cellpadding='10' cellspacing='0' height='325'>
          
		  <tr>
            <td colspan='3' height='2'><img src='banner.gif'></td>
          </tr>
		  <tr>
            <td colspan="7" bgcolor="#yellow" height="1" align="center">
		      <h1><font size="5">
	           <a href="index.php">Home</a> | 
              			   
		        <a href="search-form.php">Search </a> 
		        <a href="location.php">Location</a>|
		        <a href="announce.php">Complain</a>|
				 <a href="transfer.php">Prisoner Trans </a> ||
		        <a href="officertransfer.php">Officer</a>|
		        <a href="registration.php">Register</a>
				<a href="court.php">Court</a>
		        </font></h1>
            </td>
			 </td>
		 
            <td height='1' colspan='3' align='right' bgcolor="#006600">&nbsp;</td>
			
          </tr>
		 
          <tr>
		 
            <td width='4%' bgcolor='#FFFFFF' valign='top'>
<h3 align='center'  title='You should be online'>&nbsp;</h3></td>

            <td width='11%' valign='top' bgcolor="#FFFFFF">

<p align='center'>
 


<br/>
<div id="content">
    	<div id="gallerycontainer">
			<div class="portfolio-area" style="margin:0 auto; padding:140px 20px 20px 20px; width:720px;">	
				<iframe width="100%" height="390" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://maps.google.com.ph/maps?f=q&amp;source=s_q&amp;hl=en&amp;geocode=&amp;q=Florida+Bus+Terminal,+West+Kamias,+Quezon+City,+Metro+Manila&amp;aq=0&amp;oq=floridBarangay+West+Kamias,+Cubao,+Quezon+City,+Metro+Manila&amp;sll=14.630676,121.047814&amp;sspn=0.011772,0.021136&amp;t=h&amp;ie=UTF8&amp;hq=&amp;hnear=Florida+Bus+Terminal,+Quezon+City,+Metro+Manila&amp;ll=14.630676,121.047814&amp;spn=0.011772,0.021136&amp;z=14&amp;output=embed"></iframe><br /><small><a href="https://maps.google.com.ph/maps?f=q&amp;source=embed&amp;hl=en&amp;geocode=&amp;q=Florida+Bus+Terminal,+West+Kamias,+Quezon+City,+Metro+Manila&amp;aq=0&amp;oq=floridBarangay+West+Kamias,+Cubao,+Quezon+City,+Metro+Manila&amp;sll=14.630676,121.047814&amp;sspn=0.011772,0.021136&amp;t=h&amp;ie=UTF8&amp;hq=&amp;hnear=Florida+Bus+Terminal,+Quezon+City,+Metro+Manila&amp;ll=14.630676,121.047814&amp;spn=0.011772,0.021136&amp;z=14" style="color:#0000FF;text-align:left">View Larger Map</a></small>
				<div class="column-clear"></div>
            </div>
			<div class="clearfix"></div>
        </div>
    </div>
<br>
</td>
 <td width='75%' bgcolor='green'  valign='top'>	
<table border='0' align='center'>
<tr>
<td width="552" bgcolor="green">
<h3>  Admin Management : </h3><br/>
<ul>
<li><a href='viewofficer.php'><b>View Officer  Transfer</b></a></li>
		<br>
	<li><a href='viewprisoners.php'><b>Prisoners Information Display</b></a></li>
		<br>
		<li><a href='viewcase.php'><b>Case Information View</b></a></li>
		<br>
	<li><a href='viewtransfer.php'><b>Prisoners Transfer Information</b></a></li>
		<br>
	<li><a href='viewAnnounce.php'><b>View Comment</b></a></li>
		<br>
    <li><a href='../index.php''><b>LOG OUT</b></a></li>
</ul>
</td>
</tr>
</table>


			
			</td>
          </tr>
          <tr>
            <td colspan='3' align='center' bgcolor='#FF0000' height='1'>
					&copy; <strong>
                &nbsp;2014 KENYA PRISONS SERVICE By Mercy</strong></td>
          </tr>
	</table>
</body>
</head>
</html>
