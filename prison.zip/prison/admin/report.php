<html>
<head>
  
  <title>PRISON REPORTS </title>
   <link rel="stylesheet" media="screen" href="login.css" >
</head>
<body>
<table align="center" border="1" bgcolor="#937541" width="600" cellpadding="8" cellspacing="0" height="415">
          <tr>
            <td colspan="1" height="246"><img src="banner.gif" width="700" height="230""></td>
          </tr>
          <tr>
            <td colspan="8" bgcolor="green" height="3" align="center">
      
      
    <font size="5">  
     <a href="../index.php">Logout</a> |
         <a href="adminpanel.php">Admin Panel</a>|
          </font>

            </td>

          </tr>

         <td align="center" bgcolor="green"><h2> 

          <table align="center" border="0" bgcolor="black" width="600"   height="100">
            
            <tr>
           <nav class="navbar navbar-inverse">
           <div class="container-fluid">
           <div class="navbar-header">
           <div class="container-brand" href="#">YOU CAN GET GENERATE REPORT OF ALL</a>
           </div>
           <div>
          <ul class="nav navbar-nav">
          <td><li class="active"><a href="prisonerep.php"><button>Prisonner Report</button></a></li></td>
          <td><li><a href="transferrep.php"><button>Transfer Report</button></a></li> </td>
          <td><li><a href="courtrep.php"><button>Court Report</button></a></li></td>
          <td><li><a href="../officer/visitorep.php"><button>Visitor Report</button></a></li></td>
          <td><li><a href="Officerrep.php"><button>Officer Report</button></a></li></td>
          <td><li><a href="newprisonrep.php"><button>New Prison Report</button></a></li></td>
          <td><li><a href="Officereport.php"><button>Officer details Report</button></a></li></td>
        </ul>
      </div>
    </div>
  </nav>
        </td>
      </tr>
      </table>
     



<tr>
<td bgcolor="#937541" colspan="3" align="center">
<?php
           include("footer.php");
                ?>
</tr>
</table>
</body>
</html>


