<?php
	include("../config.php");
?>
<!DOCTYPE php>
<html>
<head>
	<title>Home</title>
	<meta charset="UTF-8">
	<link rel="stylesheet" type="text/css" href="login.css"/>
</head>
<body>
	<header>
		<img src="banner.GIF" alt="JKUAT" class="jkuat">
		<div id="header">
			
			
		</div>
	</header>


			